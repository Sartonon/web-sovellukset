#!/usr/bin/env python
{
# "singular form (0)": ["first plural form (1)", "second plural form (2)", ...],
'останній': ['останні','останніх'],
'файл': ['файли','файлів'],
'твіт': ['твіти','твітів'],
}
